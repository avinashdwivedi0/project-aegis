import { z } from "zod";
import { loginSchema, registerSchema } from "./auth.schema";

export type RegisterInput = z.infer<typeof registerSchema>;

export type LoginInput = z.infer<typeof loginSchema>;

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: "USER" | "ADMIN";
}

export interface AuthResponse {
  user: AuthUser;
  token: string;
}
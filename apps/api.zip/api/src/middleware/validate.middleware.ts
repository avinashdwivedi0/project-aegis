import { Request, Response, NextFunction } from "express";
import { ZodSchema } from "zod";

export function validate(schema: ZodSchema) {
  return (
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    const result = schema.safeParse(req.body);

    if (!result.success) {
      const errors = result.error.flatten().fieldErrors;

      const firstError =
        Object.values(errors)
          .flat()
          .find(Boolean) ?? "Validation failed";

      return res.status(400).json({
        success: false,
        message: firstError,
        errors,
      });
    }

    req.body = result.data;

    next();
  };
}
import { useState } from "react";

import type {
  CreateProjectInput,
  Project,
} from "@/types/project";

type Props = {
  initialData?: Project;
  loading?: boolean;
  submitText?: string;
  onSubmit: (
    data: CreateProjectInput
  ) => void;
};

function ProjectForm({
  initialData,
  loading = false,
  submitText = "Save Project",
  onSubmit,
}: Props) {
  const [form, setForm] = useState<CreateProjectInput>({
    name: initialData?.name ?? "",
    description:
      initialData?.description ?? "",
  });

  function handleChange(
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement
    >
  ) {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  }

  function handleSubmit(
    e: React.FormEvent<HTMLFormElement>
  ) {
    e.preventDefault();

    onSubmit({
      name: form.name.trim(),
      description:
        form.description?.trim() || "",
    });
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-6"
    >
      <div>
        <label className="mb-2 block text-sm font-medium">
          Project Name
        </label>

        <input
          name="name"
          value={form.name}
          onChange={handleChange}
          required
          minLength={3}
          maxLength={100}
          placeholder="Project Aegis"
          className="w-full rounded-xl border border-slate-700 bg-slate-900 px-4 py-3 outline-none transition focus:border-cyan-500"
        />
      </div>

      <div>
        <label className="mb-2 block text-sm font-medium">
          Description
        </label>

        <textarea
          name="description"
          rows={5}
          value={form.description}
          onChange={handleChange}
          placeholder="Describe your project..."
          className="w-full resize-none rounded-xl border border-slate-700 bg-slate-900 px-4 py-3 outline-none transition focus:border-cyan-500"
        />
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          disabled={
            loading ||
            form.name.trim().length < 3
          }
          className="rounded-xl bg-cyan-600 px-6 py-3 font-medium transition hover:bg-cyan-500 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {loading
            ? "Saving..."
            : submitText}
        </button>
      </div>
    </form>
  );
}

export default ProjectForm;
export interface EmbeddingResult {
  embedding: number[];
}

export interface EmbeddingProvider {
  generateEmbedding(text: string): Promise<number[]>;

  generateEmbeddings(texts: string[]): Promise<number[][]>;
}
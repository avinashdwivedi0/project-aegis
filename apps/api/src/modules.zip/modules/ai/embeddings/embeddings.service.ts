import { GoogleGenAI } from "@google/genai";

import type {
  EmbeddingProvider,
} from "./embeddings.types";

export class EmbeddingsService
  implements EmbeddingProvider
{
  private static readonly MODEL =
    process.env.GEMINI_EMBED_MODEL ??
    "text-embedding-004";

  private static readonly VECTOR_SIZE =
    768;

  private readonly client =
    new GoogleGenAI({
      apiKey:
        process.env.GEMINI_API_KEY!,
    });

  public async generateEmbedding(
    text: string,
  ): Promise<number[]> {
    const embedding =
      await this.client.models.embedContent({
        model:
          EmbeddingsService.MODEL,
        contents: text,
      });

    const vector =
      embedding.embeddings?.[0]?.values;

    if (!vector) {
      throw new Error(
        "Failed to generate embedding."
      );
    }

    if (
      vector.length !==
      EmbeddingsService.VECTOR_SIZE
    ) {
      throw new Error(
        `Expected ${EmbeddingsService.VECTOR_SIZE} dimensions but received ${vector.length}.`,
      );
    }

    return vector;
  }

  public async generateEmbeddings(
    texts: string[],
  ): Promise<number[][]> {
    if (texts.length === 0) {
      return [];
    }

    return Promise.all(
      texts.map((text) =>
        this.generateEmbedding(text),
      ),
    );
  }
}

export const embeddingsService =
  new EmbeddingsService();
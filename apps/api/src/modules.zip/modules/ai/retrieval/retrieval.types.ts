export interface IndexRepositoryResult {
  repositoryId: string;
  indexedFiles: number;
  indexedChunks: number;
  storedVectors: number;
  durationMs: number;
}

export interface IndexRepositoryRequest {
  repositoryId: string;
}

export interface SearchRequest {
  repositoryId: string;
  query: string;
  limit?: number;
}

export interface SearchResult {
  filePath: string;
  chunkIndex: number;
  content: string;
  score: number;

  language?: string;
  repositoryId?: string;
}
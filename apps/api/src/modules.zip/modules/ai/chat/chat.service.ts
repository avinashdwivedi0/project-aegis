import type {
  ChatRequest,
  ChatResponse,
} from "./chat.types";

import { retrievalService } from "../retrieval/retrieval.service";

interface OllamaGenerateResponse {
  response: string;
}

export class ChatService {
  private static readonly BASE_URL =
    process.env.OLLAMA_BASE_URL ??
    "http://localhost:11434";

  private static readonly MODEL =
    process.env.OLLAMA_CHAT_MODEL ??
    "qwen2.5-coder:7b";

  private static readonly SYSTEM_PROMPT = `You are Project Aegis AI.

You are an expert software engineering assistant.

Rules:

- Answer ONLY using the repository context.
- Never invent APIs, classes or files.
- If the answer cannot be determined from the repository context, respond exactly:

I couldn't find that information in the indexed repository.

When answering:
- Explain clearly.
- Mention filenames when relevant.
- Quote code only when necessary.
- Keep answers concise.
`;

  public async chat(
    request: ChatRequest,
  ): Promise<ChatResponse> {
    console.time("chat.total");

    console.time("chat.retrieval");

    const results =
      await retrievalService.search({
        repositoryId: request.repositoryId,
        query: request.message,
        limit: 5,
      });

    console.timeEnd("chat.retrieval");

    const context =
      results.length === 0
        ? "No repository context available."
        : results
            .map(
              (result) => `File: ${result.filePath}

${result.content}`,
            )
            .join(
              "\n\n==================================================\n\n",
            );

    const prompt = [
      ChatService.SYSTEM_PROMPT,
      "",
      "Repository Context:",
      context,
      "",
      "User Question:",
      request.message,
      "",
      "Answer:",
    ].join("\n");

    console.time("chat.generation");

    const response = await fetch(
      `${ChatService.BASE_URL}/api/generate`,
      {
        method: "POST",
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify({
          model: ChatService.MODEL,
          prompt,
          stream: false,
          keep_alive: "30m",
          options: {
            temperature: 0.1,
            top_p: 0.9,
            num_predict: 256,
            num_ctx: 4096,
          },
        }),
      },
    );

    console.timeEnd("chat.generation");

    if (!response.ok) {
      throw new Error(
        `Ollama request failed (${response.status})`,
      );
    }

    const data =
      (await response.json()) as OllamaGenerateResponse;

    console.timeEnd("chat.total");

    return {
      answer:
        data.response.trim(),
      sources: results.map(
        (result) => ({
          filePath:
            result.filePath,
          chunkIndex:
            result.chunkIndex,
          score: result.score,
        }),
      ),
    };
  }
}

export const chatService =
  new ChatService();
export interface AIProvider {
  generateText(prompt: string): Promise<string>;

  embedText(text: string): Promise<number[]>;

  embedTexts(texts: string[]): Promise<number[][]>;
}
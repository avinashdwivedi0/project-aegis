import { GoogleGenAI } from "@google/genai";

import { AIProvider } from "./ai.provider";

export class GeminiProvider implements AIProvider {
  private readonly client: GoogleGenAI;

  constructor() {
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not configured.");
    }

    this.client = new GoogleGenAI({
      apiKey,
    });
  }

  async generateText(prompt: string): Promise<string> {
    const response =
      await this.client.models.generateContent({
        model:
          process.env.GEMINI_CHAT_MODEL ??
          "gemini-2.5-flash",
        contents: prompt,
      });

    return response.text ?? "";
  }

  async embedText(text: string): Promise<number[]> {
    const response =
      await this.client.models.embedContent({
        model:
          process.env.GEMINI_EMBED_MODEL ??
          "text-embedding-004",
        contents: text,
      });

    const vector = response.embeddings?.[0]?.values;

    if (!vector) {
     throw new Error("Gemini returned an empty embedding.");
}

return vector;
  }

  async embedTexts(
    texts: string[],
  ): Promise<number[][]> {
    return Promise.all(
      texts.map((text) => this.embedText(text)),
    );
  }
}
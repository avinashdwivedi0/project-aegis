export interface StoreVectorInput {
  repositoryId: string;
  filePath: string;
  chunkIndex: number;
  content: string;
  embedding: number[];
}

export interface StoredVector
  extends StoreVectorInput {
  id: string;
}

export interface StoreVectorsInput {
  vectors: StoreVectorInput[];
}

export interface SearchOptions {
  repositoryId: string;
  embedding: number[];
  limit?: number;
}

export interface SearchResult {
  vector: StoredVector;
  score: number;
}
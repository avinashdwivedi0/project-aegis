import {
  ChunkOptions,
  TextChunk,
} from "./chunking.types";

export class ChunkingService {
  private static readonly DEFAULT_CHUNK_SIZE =
    1200;

  private static readonly DEFAULT_CHUNK_OVERLAP =
    200;

  private static readonly BREAK_CHARACTERS = [
    "\n\n",
    "\n",
    ". ",
    ";",
    ",",
    " ",
  ];

  public chunkText(
    text: string,
    options: ChunkOptions = {},
  ): TextChunk[] {
    if (!text.trim()) {
      return [];
    }

    const chunkSize =
      options.chunkSize ??
      ChunkingService.DEFAULT_CHUNK_SIZE;

    const chunkOverlap =
      options.chunkOverlap ??
      ChunkingService.DEFAULT_CHUNK_OVERLAP;

    if (chunkSize <= 0) {
      throw new Error(
        "chunkSize must be greater than 0",
      );
    }

    if (chunkOverlap < 0) {
      throw new Error(
        "chunkOverlap cannot be negative",
      );
    }

    if (chunkOverlap >= chunkSize) {
      throw new Error(
        "chunkOverlap must be smaller than chunkSize",
      );
    }

    const chunks: TextChunk[] = [];

    let start = 0;
    let index = 0;

    while (start < text.length) {
      let end = Math.min(
        start + chunkSize,
        text.length,
      );

      if (end < text.length) {
        end =
          this.findBestBreak(
            text,
            start,
            end,
          );
      }

      const content = text
        .slice(start, end)
        .trim();

      if (content.length > 0) {
        chunks.push({
          index,
          content,
          start,
          end,
        });

        index++;
      }

      if (end >= text.length) {
        break;
      }

      start = Math.max(
        0,
        end - chunkOverlap,
      );
    }

    return chunks;
  }

  private findBestBreak(
    text: string,
    start: number,
    preferredEnd: number,
  ): number {
    const searchWindow = 200;

    const min =
      Math.max(
        start,
        preferredEnd - searchWindow,
      );

    for (const separator of ChunkingService.BREAK_CHARACTERS) {
      const index =
        text.lastIndexOf(
          separator,
          preferredEnd,
        );

      if (index >= min) {
        return index + separator.length;
      }
    }

    return preferredEnd;
  }
}
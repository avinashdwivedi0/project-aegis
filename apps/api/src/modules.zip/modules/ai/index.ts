import { Router } from "express";

import chatRoutes from "./chat/chat.routes";

const router = Router();

router.use("/", chatRoutes);

export default router;